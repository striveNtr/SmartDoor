#ifndef _TIMER_H
#define _TIMER_H
#include "sys.h"


void  pwm_init(void);

#endif
